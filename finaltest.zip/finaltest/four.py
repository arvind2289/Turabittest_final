import json
def containinglatter(mylist):
    try:

        my_dict = {i: mylist.count(i) for i in mylist} ## using Lanbda function
        r = json.dumps(my_dict,indent=4)
        loaded_r = json.loads(r)
        return r
    except:
        print("please enter valid list")
    #print(my_dict,'helloooo')



mylist = ['python', 'pyhton3', 'user1', 'assignment', 'user', 'user1',
          'python', 'User1']
list= input("please enter list")
print(containinglatter(mylist))
print("Assignment 4 ends")
print("#####################################################")

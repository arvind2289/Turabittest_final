lowerCaseList = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
                 "u", "v", "w", "x", "y", "z"]

upperCaseList = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                 "U", "V", "W", "X", "Y", "Z"]
def assignment2():
    inputString = "hello world and practice makes perfect and hello world again"
    tempStr = ""
    processList = list()
    flag = 0
    for element in inputString:
        if element == " ":
            processList.append(tempStr)
            tempStr = ""
            flag = 0
        else:
            tempStr = tempStr + element
    processList2 = list()
    # Romoving duplicate
    for i in range(len(processList)):
        flag = 0
        j = i + 1
        for x in range(j, len(processList)):
            if processList[i] == processList[x]:
                flag = 1
        if flag == 0:
            processList2.append(processList[i])
    #  Shorting
    swap = ""
    for i in range(len(processList2)):
        j = i + 1
        for x in range(j, len(processList2)):
            if lowerCaseList.index(processList2[i][0]) > lowerCaseList.index(processList2[x][0]):
                swap = processList2[x]
                processList2[x] = processList2[i]
                processList2[i] = swap
            else:
                swap = processList2[i]
    outputString = ""
    for word in processList2:
        if outputString == "":
            outputString = word
        else:
            outputString = outputString + " " + word
    print(outputString)
    print("Assignment 2 ends")
    print("#####################################################")


assignment2()
def assignment3():
    for rabbits in range(1, 34):
        chickens = 35 - rabbits
        rabbitsLegs = 4 * rabbits
        chickensLegs = 2 * chickens
        if (rabbitsLegs + chickensLegs) == 94:
            break
    print(str(rabbits) + " rabits and " + str(chickens) + " chickens")
    print("Assignment 3 ends")
    print("#####################################################")


assignment3()
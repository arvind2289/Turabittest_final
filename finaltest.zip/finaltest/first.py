lowerCaseList = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
                 "u", "v", "w", "x", "y", "z"]

upperCaseList = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                 "U", "V", "W", "X", "Y", "Z"]


def assignment1():
    inputString = '''Hello world
					 Practice makes perfect'''
    newString = ""
    for element in inputString:
        try:
            newString = newString + upperCaseList[lowerCaseList.index(element)]
        except:
            newString = newString + element
    print(newString)
    print("Assignment 1 ends")
    print("#####################################################")


assignment1()
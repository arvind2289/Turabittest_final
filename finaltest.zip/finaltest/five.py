
def Assignment5(List):
    try:
        final_list = []
        for num in List:
            if num not in final_list:
                final_list.append(num)
        return final_list
    except:
        print("enter vaild list")

list= input("please enter list")
List =   [1,2,55,1,3,2,34,55]
print(Assignment5(List))
print("Assignment 5 ends")
print("#####################################################")